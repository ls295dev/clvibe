import random

# -------------------------------
# CONFIGURATION
# -------------------------------

TIER_DATA = [
    {
        "tier": 1,
        "map_size": 3,
        "ghosts": {
            "Basic Ghost": {"emf": 5, "spirit_box": True, "cold": False, "moves": False, "aggression": 0}
        },
        "tools": ["emf", "spirit_box"],
        "payout": 100
    },
    {
        "tier": 2,
        "map_size": 5,
        "ghosts": {
            "Revenant": {"emf": 5, "spirit_box": False, "cold": True, "moves": True, "aggression": 2},
            "Poltergeist": {"emf": 2, "spirit_box": True, "cold": False, "moves": False, "aggression": 1}
        },
        "tools": ["emf", "spirit_box", "thermometer"],
        "payout": 200
    },
    {
        "tier": 3,
        "map_size": 6,
        "ghosts": {
            "Phantom": {"emf": 3, "spirit_box": False, "cold": True, "moves": True, "aggression": 3},
            "Banshee": {"emf": 2, "spirit_box": True, "cold": True, "moves": True, "aggression": 2}
        },
        "tools": ["emf", "spirit_box", "thermometer", "motion_detector"],
        "payout": 300
    }
]

RANDOM_EVENTS = [
    "You hear whispering in the walls...",
    "Lights flicker suddenly.",
    "Cold air brushes your neck.",
    "A knock echoes through the hallway..."
]


class Room:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.has_ghost = False

    def evidence(self, ghost, ghost_here):
        if ghost_here:
            return {
                "emf": ghost["emf"],
                "spirit_box": ghost["spirit_box"],
                "cold": ghost["cold"]
            }
        else:
            return {
                "emf": random.choice([0, 1, 2]),
                "spirit_box": random.choice([False, False, True]),
                "cold": random.choice([False, False, True])
            }


class Player:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.sanity = 100
        self.money = 150
        self.inventory = {"sanity_pills": 0}
        self.evidence = {"emf": False, "spirit_box": False, "cold": False}
        self.turns_used = 0
        self.ghost_guess = None
        self.tools = {
            "emf": True,
            "spirit_box": True,
            "thermometer": False,
            "motion_detector": False
        }

    def use_sanity_pill(self):
        if self.inventory["sanity_pills"] > 0:
            self.sanity = min(100, self.sanity + 30)
            self.inventory["sanity_pills"] -= 1
            print("💊 You used a sanity pill. Sanity restored!")
        else:
            print("❌ No sanity pills left.")


class Game:
    def __init__(self, tier_index=0, tutorial=False):
        self.tier = TIER_DATA[tier_index]
        self.map_size = self.tier["map_size"]
        self.tools_available = self.tier["tools"]
        self.ghost_name, self.ghost = random.choice(list(self.tier["ghosts"].items()))
        self.map = [[Room(x, y) for y in range(self.map_size)] for x in range(self.map_size)]
        self.ghost_location = [random.randint(0, self.map_size-1), random.randint(0, self.map_size-1)]
        self.map[self.ghost_location[0]][self.ghost_location[1]].has_ghost = True
        self.player = Player()
        self.max_turns = 20
        self.payout = self.tier["payout"]
        self.tutorial = tutorial
        if tutorial:
            self.start_tutorial()

    def start_tutorial(self):
        print("\n🎓 Welcome to Ghost Hunter Simulator!")
        print("In this tutorial, you'll learn the basics.")
        input("Press Enter to continue...")
        print("\nYou are in a haunted house. Your job is to identify the ghost’s location.")
        input("Press Enter to continue...")
        print("\n🔎 Try typing `emf` now to scan.")
        while True:
            cmd = input("> ").strip().lower()
            if cmd == "emf":
                self.use_tool("emf")
                break
            else:
                print("Type `emf` to continue the tutorial.")
        print("\n✅ Nice! Now try `spirit` to use the spirit box.")
        while True:
            cmd = input("> ").strip().lower()
            if cmd == "spirit":
                self.use_tool("spirit_box")
                break
            else:
                print("Type `spirit` to continue the tutorial.")
        print("\n🎯 You’re ready! Type `move north` to move around. Then `guess x y` to identify the ghost’s room.")
        print("Type `quit` anytime to leave the mission.\n")

    def get_room(self):
        return self.map[self.player.x][self.player.y]

    def move_player(self, direction):
        dx, dy = {"north": (0, -1), "south": (0, 1), "east": (1, 0), "west": (-1, 0)}.get(direction, (0, 0))
        nx, ny = self.player.x + dx, self.player.y + dy
        if 0 <= nx < self.map_size and 0 <= ny < self.map_size:
            self.player.x, self.player.y = nx, ny
            self.player.turns_used += 1
            self.trigger_event()
        else:
            print("❌ Can't move that way.")

    def use_tool(self, tool):
        room = self.get_room()
        ghost_here = [self.player.x, self.player.y] == self.ghost_location
        ev = room.evidence(self.ghost, ghost_here)

        if tool == "emf" and "emf" in self.tools_available:
            print(f"📟 EMF Reading: {ev['emf']}")
            if ev["emf"] == self.ghost["emf"]:
                self.player.evidence["emf"] = True
        elif tool == "spirit_box" and "spirit_box" in self.tools_available:
            print(f"🔊 Spirit Box: {'Ghost responds' if ev['spirit_box'] else 'No response'}")
            if ev["spirit_box"]:
                self.player.evidence["spirit_box"] = True
        elif tool == "thermometer" and "thermometer" in self.tools_available:
            print(f"🌡️ Temp: {'Freezing' if ev['cold'] else 'Normal'}")
            if ev["cold"]:
                self.player.evidence["cold"] = True
        elif tool == "motion_detector" and "motion_detector" in self.tools_available:
            gx, gy = self.ghost_location
            if abs(gx - self.player.x) + abs(gy - self.player.y) == 1:
                print("🚨 Motion nearby!")
            else:
                print("📡 No motion.")
        else:
            print("❌ Tool not available.")

    def trigger_event(self):
        if random.random() < 0.3 + 0.1 * self.ghost["aggression"]:
            print(f"⚠️ Event: {random.choice(RANDOM_EVENTS)}")
            self.player.sanity -= random.randint(5, 10) * (1 + self.ghost["aggression"])

    def guess_location(self, x, y):
        self.player.ghost_guess = [x, y]

    def finish_game(self):
        correct = self.player.ghost_guess == self.ghost_location
        full_evidence = all([
            (not self.ghost.get("cold") or self.player.evidence["cold"]),
            (not self.ghost.get("spirit_box") or self.player.evidence["spirit_box"]),
            (not self.ghost.get("emf") or self.player.evidence["emf"])
        ])
        print("\n📜 Contract Report:")
        print(f"Your guess: {self.player.ghost_guess}")
        print(f"Actual: {self.ghost_location}")
        print(f"Ghost: {self.ghost_name}")
        print(f"Evidence: {self.player.evidence}")
        print(f"Sanity: {self.player.sanity}%")

        if correct and full_evidence:
            print("✅ Mission Complete! Full payout.")
            self.player.money += self.payout
            return True
        elif correct:
            print("🟡 Location correct, but missing evidence. Half pay.")
            self.player.money += self.payout // 2
            return True
        else:
            print("❌ Contract failed.")
            return False


def visit_store(player: Player, tools_available: list):
    print("\n🛒 Welcome to the Equipment Store!")
    store_items = {
        "sanity_pill": {"name": "Sanity Pill", "cost": 50},
        "thermometer": {"name": "Thermometer", "cost": 100},
        "motion_detector": {"name": "Motion Detector", "cost": 150},
    }

    while True:
        print(f"\n💵 Current Balance: ${player.money}")
        print("Available items:")
        for key, item in store_items.items():
            if key == "sanity_pill":
                print(f"- {item['name']} (${item['cost']}) — `sanity_pill` to buy")
            elif key in tools_available and not player.tools.get(key, False):
                print(f"- {item['name']} (${item['cost']}) — `{key}` to buy")
        print("Type `done` when finished.\n")
        choice = input("> ").strip().lower()

        if choice == "done":
            break
        elif choice in store_items:
            item = store_items[choice]
            if player.money >= item["cost"]:
                player.money -= item["cost"]
                if choice == "sanity_pill":
                    player.inventory["sanity_pills"] += 1
                    print("💊 Purchased 1x Sanity Pill.")
                else:
                    player.tools[choice] = True
                    print(f"🧰 You purchased {item['name']}.")
            else:
                print("❌ Not enough money.")
        else:
            print("❌ Invalid choice.")


def main():
    print("👻 Welcome to Ghost Hunter Simulator!")
    print("Type `tutorial` to learn or `start` to begin your first mission.")
    mode = input("> ").strip().lower()

    if mode == "tutorial":
        game = Game(tutorial=True)
    else:
        game = Game()

    # Skip store in tutorial mode
    if not game.tutorial:
        visit_store(game.player, game.tools_available)

    while game.player.turns_used < game.max_turns and game.player.sanity > 0:
        print(f"\n📍 ({game.player.x},{game.player.y}) | Sanity: {game.player.sanity}% | $: {game.player.money}")
        print("Commands: move [north/south/east/west], emf, spirit, thermo, motion, guess x y, use pill, quit")
        cmd = input("> ").strip().lower()

        if cmd.startswith("move"):
            parts = cmd.split()
            if len(parts) == 2:
                game.move_player(parts[1])
            else:
                print("❌ Invalid move command.")
        elif cmd == "emf":
            game.use_tool("emf")
        elif cmd == "spirit":
            game.use_tool("spirit_box")
        elif cmd == "thermo":
            game.use_tool("thermometer")
        elif cmd == "motion":
            game.use_tool("motion_detector")
        elif cmd.startswith("guess"):
            parts = cmd.split()
            if len(parts) == 3 and parts[1].isdigit() and parts[2].isdigit():
                x, y = int(parts[1]), int(parts[2])
                if 0 <= x < game.map_size and 0 <= y < game.map_size:
                    game.guess_location(x, y)
                    print(f"🎯 You guessed the ghost is at ({x},{y}).")
                    game.player.turns_used += 1
                else:
                    print("❌ Guess coordinates out of range.")
            else:
                print("❌ Invalid guess command.")
        elif cmd == "use pill":
            game.player.use_sanity_pill()
        elif cmd == "quit":
            print("👋 Mission aborted.")
            break
        else:
            print("❌ Unknown command.")

    print("\n⏰ Time's up or sanity depleted!")
    game.finish_game()


if __name__ == "__main__":
    main()

