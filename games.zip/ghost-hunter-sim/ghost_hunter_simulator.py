import random

# -------------------------------
# CONFIGURATION
# -------------------------------

TIER_DATA = [
    {
        "tier": 1,
        "map_size": 3,
        "ghosts": {
            "Basic Ghost": {
                "emf": 5,
                "spirit_box": True,
                "cold": False,
                "moves": False,
                "aggression": 0,
                "motion_sensitive": True,
                "spirit_response_chance": 0.7
            }
        },
        "tools": ["emf", "spirit_box"],
        "payout": 100
    },
    {
        "tier": 2,
        "map_size": 5,
        "ghosts": {
            "Revenant": {
                "emf": 5,
                "spirit_box": False,
                "cold": True,
                "moves": True,
                "aggression": 2,
                "motion_sensitive": True,
                "spirit_response_chance": 0.3
            },
            "Poltergeist": {
                "emf": 2,
                "spirit_box": True,
                "cold": False,
                "moves": False,
                "aggression": 1,
                "motion_sensitive": True,
                "spirit_response_chance": 0.6
            }
        },
        "tools": ["emf", "spirit_box", "thermometer"],
        "payout": 200
    },
    {
        "tier": 3,
        "map_size": 6,
        "ghosts": {
            "Phantom": {
                "emf": 3,
                "spirit_box": False,
                "cold": True,
                "moves": True,
                "aggression": 3,
                "motion_sensitive": False,
                "spirit_response_chance": 0.2
            },
            "Banshee": {
                "emf": 2,
                "spirit_box": True,
                "cold": True,
                "moves": True,
                "aggression": 2,
                "motion_sensitive": True,
                "spirit_response_chance": 0.5
            },
            "Shade": {
                "emf": 1,
                "spirit_box": True,
                "cold": True,
                "moves": True,
                "aggression": 1,
                "motion_sensitive": False,
                "spirit_response_chance": 0.3
            },
            "Mimic": {
                "emf": 4,
                "spirit_box": True,
                "cold": False,
                "moves": True,
                "aggression": 4,
                "motion_sensitive": True,
                "spirit_response_chance": 0.4
            },
            "Doppelganger": {
                "emf": 3,
                "spirit_box": False,
                "cold": True,
                "moves": True,
                "aggression": 3,
                "motion_sensitive": False,
                "spirit_response_chance": 0.1
            }
        },
        "tools": ["emf", "spirit_box", "thermometer", "motion_detector", "matrix_map"],
        "payout": 300
    }
]

RANDOM_EVENTS = [
    "You hear whispering in the walls...",
    "Lights flicker suddenly.",
    "Cold air brushes your neck.",
    "A knock echoes through the hallway..."
]

SPIRIT_BOX_RESPONSES = [
    "Leave now...",
    "I'm still here.",
    "Go away.",
    "You shouldn't be here.",
    "Help me...",
    "Who are you?",
    "I am watching.",
    "This is my home.",
]

# -------------------------------
# CLASSES
# -------------------------------

class Room:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.has_ghost = False

    def evidence(self, ghost, ghost_here):
        if ghost_here:
            return {
                "emf": ghost["emf"],
                "spirit_box": random.random() < ghost.get("spirit_response_chance", 0.5) if ghost.get("spirit_box", False) else False,
                "cold": ghost["cold"]
            }
        else:
            return {
                "emf": random.choice([0, 1, 2]),
                "spirit_box": random.choice([False, False, True]),
                "cold": random.choice([False, False, True])
            }

class Player:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.sanity = 100
        self.money = 50  # Starter cash lowered for shop balance
        self.inventory = {
            "sanity_pills": 0,
            "motion_detector": 0,
            "matrix_map": 0
        }
        self.evidence = {"emf": False, "spirit_box": False, "cold": False}
        self.turns_used = 0
        self.ghost_guess = None
        self.tools = {
            "emf": True,
            "spirit_box": True,
            "thermometer": False,
            "motion_detector": False,
            "matrix_map": False
        }
        self.recordings = 0  # Count of spirit box name recordings

    def use_sanity_pill(self):
        if self.inventory["sanity_pills"] > 0:
            self.sanity = min(100, self.sanity + 30)
            self.inventory["sanity_pills"] -= 1
            print("💊 You used a sanity pill. Sanity restored!")
        else:
            print("❌ No sanity pills left.")

class Game:
    def __init__(self, tier_index=0, tutorial=False):
        self.tier = TIER_DATA[tier_index]
        self.map_size = self.tier["map_size"]
        self.tools_available = self.tier["tools"]
        self.ghost_name, self.ghost = random.choice(list(self.tier["ghosts"].items()))
        self.map = [[Room(x, y) for y in range(self.map_size)] for x in range(self.map_size)]
        self.ghost_location = [random.randint(0, self.map_size - 1), random.randint(0, self.map_size - 1)]
        self.map[self.ghost_location[0]][self.ghost_location[1]].has_ghost = True
        self.player = Player()
        self.max_turns = 20
        self.payout = self.tier["payout"]
        self.tutorial = tutorial
        self.motion_detectors_placed = {}  # {(x,y): True}
        if tutorial:
            self.start_tutorial()

    def start_tutorial(self):
        print("\n🎓 Welcome to Ghost Hunter Simulator!")
        print("In this tutorial, you'll learn the basics.")
        input("Press Enter to continue...")
        print("\nYou are in a haunted house. Your job is to identify the ghost’s location.")
        input("Press Enter to continue...")
        print("\n🔎 Try typing `emf` now to scan.")
        while True:
            cmd = input("> ").strip().lower()
            if cmd == "emf":
                self.use_tool("emf")
                break
            else:
                print("Type `emf` to continue the tutorial.")
        print("\n✅ Nice! Now try `spirit` to use the spirit box.")
        while True:
            cmd = input("> ").strip().lower()
            if cmd == "spirit":
                self.use_tool("spirit_box")
                break
            else:
                print("Type `spirit` to continue the tutorial.")
        print("\n🎯 You’re ready! Type `move north` to move around. Then `guess x y` to identify the ghost’s room.")
        print("Type `quit` anytime to leave the mission.\n")

    def get_room(self):
        return self.map[self.player.x][self.player.y]

    def move_player(self, direction):
        dx, dy = {"north": (0, -1), "south": (0, 1), "east": (1, 0), "west": (-1, 0)}.get(direction, (0, 0))
        nx, ny = self.player.x + dx, self.player.y + dy
        if 0 <= nx < self.map_size and 0 <= ny < self.map_size:
            self.player.x, self.player.y = nx, ny
            self.player.turns_used += 1
            self.trigger_event()
            # Check motion detectors placed for ghost presence
            self.check_motion_detectors()
        else:
            print("❌ Can't move that way.")

    def check_motion_detectors(self):
        # Ghost moves only if moves = True
        if not self.ghost.get("moves", False):
            return

        # Simulate ghost movement randomly to adjacent cell or stays
        gx, gy = self.ghost_location
        possible_moves = [(gx, gy)]
        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nx, ny = gx + dx, gy + dy
            if 0 <= nx < self.map_size and 0 <= ny < self.map_size:
                possible_moves.append((nx, ny))

        new_location = random.choice(possible_moves)
        self.map[gx][gy].has_ghost = False
        self.map[new_location[0]][new_location[1]].has_ghost = True
        self.ghost_location = list(new_location)

        # Check if ghost triggered any motion detector
        for (mx, my) in self.motion_detectors_placed.keys():
            if (mx, my) == self.ghost_location:
                if self.ghost.get("motion_sensitive", True):
                    print("🚨 Motion Detector ping! Ghost moved onto a motion sensor at", (mx, my))
                else:
                    # Some ghosts do not trigger motion detectors
                    print(f"🚨 Motion Detector detected something unusual, but no ghost detected (ghost type: {self.ghost_name}).")

    def use_tool(self, tool):
        room = self.get_room()
        ghost_here = [self.player.x, self.player.y] == self.ghost_location
        if tool == "emf":
            if not self.player.tools.get("emf", False):
                print("❌ You don't have EMF reader.")
                return
            level = self.ghost["emf"] if ghost_here else random.randint(0, 2)
            print(f"📡 EMF Reading: Level {level}")
            if level >= 4:
                self.player.evidence["emf"] = True

        elif tool == "spirit_box":
            if not self.player.tools.get("spirit_box", False):
                print("❌ You don't have Spirit Box.")
                return
            respond_chance = self.ghost["spirit_response_chance"]
            if random.random() < respond_chance:
                response = random.choice(SPIRIT_BOX_RESPONSES)
                print(f"📻 Spirit Box response: {response}")
                self.player.evidence["spirit_box"] = True

                ask = input("Do you want to ask the ghost's name? (yes/no) ").strip().lower()
                if ask == "yes":
                    # 70% chance ghost answers name
                    if random.random() < respond_chance:
                        print(f"The ghost whispers its name: {self.ghost_name}")
                        record = input("Do you want to record this name to sell later? (yes/no) ").strip().lower()
                        if record == "yes":
                            self.player.recordings += 1
                            print("🎙️ Name recording saved.")
                    else:
                        print("The ghost remains silent.")
            else:
                print("📻 No response from the spirit box.")

        elif tool == "thermometer":
            if not self.player.tools.get("thermometer", False):
                print("❌ You don't have Thermometer.")
                return
            cold = self.ghost["cold"] if ghost_here else False
            print("🌡️ Temperature drop detected!" if cold else "🌡️ No temperature anomaly.")
            if cold:
                self.player.evidence["cold"] = True

        elif tool == "motion_detector":
            if not self.player.tools.get("motion_detector", False):
                print("❌ You don't have Motion Detectors.")
                return
            place = input("Place motion detector at coordinates (x y)? ").strip()
            try:
                x_str, y_str = place.split()
                x, y = int(x_str), int(y_str)
                if 0 <= x < self.map_size and 0 <= y < self.map_size:
                    self.motion_detectors_placed[(x, y)] = True
                    print(f"Motion detector placed at ({x},{y}).")
                    self.player.inventory["motion_detector"] -= 1
                    if self.player.inventory["motion_detector"] <= 0:
                        self.player.tools["motion_detector"] = False
                else:
                    print("Invalid coordinates.")
            except:
                print("Invalid input format.")

        elif tool == "matrix_map":
            if not self.player.tools.get("matrix_map", False):
                print("❌ You don't have Matrix Map.")
                return
            print("🗺️ Matrix Map of the haunted location:")
            self.display_ascii_map()

    def display_ascii_map(self):
        # Map legend:
        # G = Ghost
        # P = Player
        # D = Doors (here just show door at edges between rooms)
        for y in range(self.map_size):
            # Print top doors row
            top_row = ""
            for x in range(self.map_size):
                top_row += "  " if y == 0 else "--"  # Doors between rows
                top_row += "   "
            print(top_row)
            # Print room row
            room_row = ""
            for x in range(self.map_size):
                left_door = "|" if x > 0 else " "
                if [x, y] == self.ghost_location:
                    content = "G"
                elif [x, y] == [self.player.x, self.player.y]:
                    content = "P"
                else:
                    content = " "
                room_row += f"{left_door} {content} "
            room_row += "|"
            print(room_row)
        # Print bottom door line
        print(" " + "---" * self.map_size)

    def guess_ghost_location(self, x, y):
        if x == self.ghost_location[0] and y == self.ghost_location[1]:
            print("🎉 You guessed correctly! Mission success!")
            reward = self.payout + self.player.recordings * 50
            print(f"💰 You earned ${reward} including selling {self.player.recordings} recordings.")
            self.player.money += reward
            self.player.recordings = 0
            return True
        else:
            print("❌ Wrong location guess. Mission failed.")
            # Pay for recordings anyway
            if self.player.recordings > 0:
                recording_pay = self.player.recordings * 50
                self.player.money += recording_pay
                print(f"💰 You sold {self.player.recordings} spirit box recordings for ${recording_pay}.")
                self.player.recordings = 0
            # Lower tier next mission (if possible)
            print("You will try next mission in lower tier.")
            return False

    def shop(self):
        print("\n🛒 Welcome to the Tool Shop!")
        print(f"You have ${self.player.money}.")
        shop_items = {
            "sanity_pills": {"price": 20},
            "motion_detector": {"price": 100},
            "matrix_map": {"price": 150},
            "thermometer": {"price": 80},
        }
        print("Available items:")
        for item, info in shop_items.items():
            print(f"- {item.replace('_', ' ').title()} - ${info['price']}")
        while True:
            buy = input("Type item name to buy, or `exit` to leave shop: ").strip().lower()
            if buy == "exit":
                break
            elif buy in shop_items:
                qty_str = input("How many do you want to buy? ").strip()
                if not qty_str.isdigit() or int(qty_str) < 1:
                    print("Invalid quantity.")
                    continue
                qty = int(qty_str)
                total_cost = shop_items[buy]["price"] * qty
                if total_cost > self.player.money:
                    print("Not enough money.")
                    continue
                self.player.money -= total_cost
                if buy == "sanity_pills":
                    self.player.inventory["sanity_pills"] += qty
                else:
                    # Add to inventory and enable tool
                    if buy not in self.player.inventory:
                        self.player.inventory[buy] = 0
                    self.player.inventory[buy] += qty
                    self.player.tools[buy] = True
                print(f"Bought {qty} {buy.replace('_',' ')}(s).")
            else:
                print("Item not found.")

    def run(self):
        print(f"\n🚪 Starting mission tier {self.tier['tier']} - Map size {self.map_size}x{self.map_size}")
        print(f"Ghost Type: ??? (can ask via spirit box)")
        print(f"You have {self.max_turns} turns.")
        while self.player.turns_used < self.max_turns:
            print(f"\nTurns left: {self.max_turns - self.player.turns_used}, Sanity: {self.player.sanity}, Money: ${self.player.money}")
            cmd = input("Enter command (move north/south/east/west, emf, spirit, thermometer, motion_detector, matrix_map, pill, guess x y, shop, quit): ").strip().lower()
            if cmd.startswith("move "):
                direction = cmd.split()[1]
                self.move_player(direction)
            elif cmd in ["emf", "spirit", "thermometer", "motion_detector", "matrix_map"]:
                self.use_tool(cmd if cmd != "spirit" else "spirit_box")
            elif cmd == "pill":
                self.player.use_sanity_pill()
            elif cmd.startswith("guess"):
                parts = cmd.split()
                if len(parts) == 3 and parts[1].isdigit() and parts[2].isdigit():
                    x, y = int(parts[1]), int(parts[2])
                    if self.guess_ghost_location(x, y):
                        break
                    else:
                        # Fail mission; next tier down or restart lowest tier
                        next_tier = max(0, self.tier["tier"] - 2)
                        new_game = Game(next_tier)
                        new_game.player = self.player  # carry money and inventory over
                        new_game.run()
                        return
                else:
                    print("Invalid guess command. Format: guess x y")
            elif cmd == "shop":
                self.shop()
            elif cmd == "quit":
                print("Exiting mission.")
                break
            else:
                print("Unknown command.")
        else:
            print("Mission time expired. You failed to locate the ghost.")
            if self.player.recordings > 0:
                recording_pay = self.player.recordings * 50
                self.player.money += recording_pay
                print(f"💰 You sold {self.player.recordings} spirit box recordings for ${recording_pay}.")
                self.player.recordings = 0

# -------------------------------
# RUN GAME
# -------------------------------

if __name__ == "__main__":
    game = Game(tier_index=0, tutorial=True)
    game.run()

