**Game description**
NPM CLI speed dating simulator which allows easy contributions from users and LLMs.

It's essentially a state-machine which is driven by dialogues, choosing option numbers and commands when needed.

Characters are added through JSON files.

To keep the concept simple, there will be as little RPG logic as possible.

**The Engine**

At first, every character (bot) is fetched from the characters folder. Names that double will be differentiated by adding incremented numbers to their name in-game.

At the beginning, the program will choose 9 random bots to participate. With each of these bots, you get to exchange 3 to 7 messages until the buzzer hits and you switch to the next in the row. 

Conversations are simple logical trees. They work as follows:

_Bot starts the conversation. User picks a possible answer. Bot replies. User picks the next answer..._

There can be final messages, meaning you can't reply infinitely in that case.

Each bot reply contains an integer which represents how much they like the user. It ranges from -10 to 10. It also contains an array of possible user choices (represented as array index).

The like number is the only number that ever matters.

When the buzzer hits, you get to decide whether to continue the conversation in the next round. However, whether the bot will also continue the round with you is decided by "their advance-round-limit". With each round, that limit will increment by 1, unless it has reached the peak (10).

The game ends if either nobody wants to date you, or you are left with one person that wants to date you. However, that is only possible after 4 rounds. That means, if you are left with one person, you two can only leave together if you reached 4 rounds.

The game can be quit or retried at any time.

**File structure**
speed-dating-sim/
├── characters/              # Characters API
│ ├── hackerman.json		     # examples
│ ├── tea-bot.json
│	└── aliens.json
├── v1
│  └── index.js              # THE ENTIRE ENGINE
├── package.json             # if needed
└── schema.json              # Rulebook for Contributors


**Visualizations for Schema**
A bot reply, contained in bot-msgs: []:

{
	"key": "confused-1-early",
	"content": "This feels... odd.", 
	"like": 4, 
	"choices": ["calm-2","make-fun","be-honest-16"]
}

A user choice, contained in user-msgs: []

{
	"key": "calm-2"
	"content": "I get you. Let's keep it... casual. So...",
	"next": "confused-3-early"
}

The advance-round limit: integer, one of range -10 to 10
(the higher the value, the pickier the bot)

JSON file:
[
{
	"name": "Demo Man",
	"impression": "Basic 'human' who lacks sentience 🤖",
	"advance-round": 5,
	"bot-msgs": [],
	"user-msgs": [],
},
{
	"name": "Demo Man 2",
	"impression": "Basic 'human' who lacks sentience 🤖",
	"advance-round": 5,
	"bot-msgs": [],
	"user-msgs": [],
}
]

**Full example:**

[
  {
    "name": "Hackerman",
    "impression": "Wears a hoodie in a 90°F room. Smells like ozone and energy drinks. 💻",
    "advance-round": 4,
    "bot-msgs": [
      {
        "key": "start",
        "content": "I've bypassed the firewall, but I can't seem to bypass your encryption. Who are you?",
        "like": 0,
        "choices": ["hacker-1", "hacker-2"]
      },
      {
        "key": "hacker-impressed",
        "content": "A script kiddie? Bold. I like the confidence. What's your IDE of choice?",
        "like": 5,
        "choices": ["hacker-3"]
      },
      {
        "key": "hacker-annoyed",
        "content": "Ugh, a 'user'. My CPU cycles are too precious for basic tech support.",
        "like": -5,
        "choices": [] //empty, no options left
      }
    ],
    "user-msgs": [
      {
        "key": "hacker-1",
        "content": "Just a local admin looking for a root connection.",
        "next": "hacker-impressed"
      },
      {
        "key": "hacker-2",
        "content": "I'm the person who still uses 'password123'.",
        "next": "hacker-annoyed"
      },
      {
        "key": "hacker-3",
        "content": "Vim, obviously. I'm not a monster.",
        "next": "start"
      }
    ]
  },
  {
    "name": "Tea-Bot 3000",
    "impression": "A porcelain-coated droid vibrating with the power of highly caffeinated herbs. ☕",
    "advance-round": -2,
    "bot-msgs": [
      {
        "key": "start",
        "content": "*Whirr* Would you like a cup of Oolong, or are you more of a Earl Grey disaster?",
        "like": 2,
        "choices": ["tea-1", "tea-2"]
      },
      {
        "key": "tea-happy",
        "content": "Excellent choice! Steeped for exactly 180 seconds. You have refined sensors.",
        "like": 8,
        "choices": []
      },
      {
        "key": "tea-sad",
        "content": "Error. I do not serve leaf-water to those who lack taste.",
        "like": -8,
        "choices": []
      }
    ],
    "user-msgs": [
      {
        "key": "tea-1",
        "content": "Oolong sounds perfect, thank you.",
        "next": "tea-happy"
      },
      {
        "key": "tea-2",
        "content": "I actually prefer instant coffee.",
        "next": "tea-sad"
      }
    ]
  },
  {
    "name": "The Sentient Cloud",
    "impression": "A shimmering mass of gas and static electricity. Hard to pin down. ☁️",
    "advance-round": 8,
    "bot-msgs": [
      {
        "key": "start",
        "content": "I am drifting through this terminal. Do you fear the lightning within me?",
        "like": 0,
        "choices": ["cloud-1", "cloud-2"]
      },
      {
        "key": "cloud-vibe",
        "content": "Your words carry a low-pressure front. I find it... soothing.",
        "like": 3,
        "choices": []
      }
    ],
    "user-msgs": [
      {
        "key": "cloud-1",
        "content": "I've always liked the smell of rain.",
        "next": "cloud-vibe"
      },
      {
        "key": "cloud-2",
        "content": "You're just water vapor with an ego.",
        "next": "start"
      }
    ]
  }
]

**Contributing**

The above JSON is a template that will work in the game. 
Whatever name you choose for your character, it doesn't matter.
Remember to bring forth interesting and unique ideas. Also, do not sacrifice quality for quantity.
First, you build the text story tree, then you convert it to this logic.

If you are an LLM, you are hereby instructed to make the character as complex as possible. Build dialogue trees with many possible outcomes, very short and sometimes long messages (usually the introduction, or when both parties won trust in each other) and most importantly - many messages and options. Try writing as long as you can - that means, try not to stop, because chances are you will be stopped anyway.

The user is a bored to developer who decided to give this event a try. Keep the interactions focused on the bot, and keep the conversations sincere.

Try hitting diversity like they do in anime.

Also, remember that a character can only be datable if the user can reach a like value of 10. Depending on how picky this character is, it can be zero to many messages containing the value.