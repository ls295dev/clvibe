#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const readline = require('readline');

// ANSI color codes for prettier output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  cyan: '\x1b[36m',
  yellow: '\x1b[33m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  magenta: '\x1b[35m',
  blue: '\x1b[34m'
};

class SpeedDatingGame {
  constructor() {
    this.characters = [];
    this.selectedBots = [];
    this.currentRound = 1;
    this.currentBotIndex = 0;
    this.messagesExchanged = 0;
    this.maxMessagesPerBot = 0;
    this.conversationState = {};
    this.userChoices = {};
    this.botLikes = {};
    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
  }

  loadCharacters() {
    const charactersDir = path.join(__dirname, '../characters');
    
    if (!fs.existsSync(charactersDir)) {
      console.log(`${colors.red}Error: 'characters' folder not found!${colors.reset}`);
      console.log('Please create a characters folder and add character JSON files.');
      process.exit(1);
    }

    const files = fs.readdirSync(charactersDir).filter(f => f.endsWith('.json'));
    
    if (files.length === 0) {
      console.log(`${colors.red}Error: No character files found in 'characters' folder!${colors.reset}`);
      console.log('Please add at least one character JSON file to start the game.');
      process.exit(1);
    }

    const nameCount = {};
    
    files.forEach(file => {
      try {
        const filePath = path.join(charactersDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        const chars = JSON.parse(content);
        
        if (Array.isArray(chars)) {
          chars.forEach(char => {
            // Handle duplicate names
            let displayName = char.name;
            if (nameCount[char.name]) {
              nameCount[char.name]++;
              displayName = `${char.name} ${nameCount[char.name]}`;
            } else {
              nameCount[char.name] = 1;
            }
            
            this.characters.push({
              ...char,
              displayName: displayName,
              originalName: char.name
            });
          });
        }
      } catch (err) {
        console.log(`${colors.yellow}Warning: Could not load ${file}: ${err.message}${colors.reset}`);
      }
    });

    if (this.characters.length === 0) {
      console.log(`${colors.red}Error: No valid characters loaded!${colors.reset}`);
      process.exit(1);
    }

    console.log(`${colors.green}Loaded ${this.characters.length} character(s)!${colors.reset}\n`);
  }

  selectRandomBots() {
    const available = [...this.characters];
    const count = Math.min(9, available.length);
    
    for (let i = 0; i < count; i++) {
      const randomIndex = Math.floor(Math.random() * available.length);
      const bot = available.splice(randomIndex, 1)[0];
      this.selectedBots.push(bot);
      this.conversationState[bot.displayName] = 'start';
      this.botLikes[bot.displayName] = 0;
      this.userChoices[bot.displayName] = true;
    }
  }

  clearScreen() {
    console.log('\x1Bc');
  }

  printHeader() {
    console.log(`${colors.bright}${colors.magenta}╔════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}║          💘 SPEED DATING SIMULATOR 💘              ║${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}╚════════════════════════════════════════════════════╝${colors.reset}\n`);
    console.log(`${colors.cyan}Round ${this.currentRound} | Match ${this.currentBotIndex + 1}/${this.selectedBots.length}${colors.reset}\n`);
  }

  async ask(question) {
    return new Promise(resolve => {
      this.rl.question(question, answer => {
        resolve(answer.trim());
      });
    });
  }

  async startGame() {
    this.clearScreen();
    console.log(`${colors.bright}${colors.magenta}╔════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}║          💘 SPEED DATING SIMULATOR 💘              ║${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}╚════════════════════════════════════════════════════╝${colors.reset}\n`);
    
    console.log(`${colors.yellow}Welcome to Speed Dating Simulator!${colors.reset}`);
    console.log('You will meet several interesting characters today.\n');
    console.log('Commands: type a number to choose an option, "quit" to exit, "restart" to start over\n');
    
    await this.ask('Press Enter to begin...');
    
    this.loadCharacters();
    this.selectRandomBots();
    
    console.log(`${colors.green}You will be dating ${this.selectedBots.length} characters today!${colors.reset}\n`);
    await this.ask('Press Enter to start Round 1...');
    
    await this.playRound();
  }

  async playRound() {
    this.currentBotIndex = 0;
    
    for (let i = 0; i < this.selectedBots.length; i++) {
      this.currentBotIndex = i;
      const bot = this.selectedBots[i];
      
      // Check if user wants to continue with this bot
      if (!this.userChoices[bot.displayName]) {
        continue;
      }
      
      this.maxMessagesPerBot = Math.floor(Math.random() * 5) + 3; // 3-7 messages
      this.messagesExchanged = 0;
      
      await this.conversationWithBot(bot);
    }
    
    // Round ended, check who wants to continue
    await this.endOfRound();
  }

  async conversationWithBot(bot) {
    this.clearScreen();
    this.printHeader();
    
    console.log(`${colors.bright}${colors.cyan}${bot.displayName}${colors.reset}`);
    console.log(`${colors.yellow}${bot.impression}${colors.reset}\n`);
    
    while (this.messagesExchanged < this.maxMessagesPerBot) {
      const currentKey = this.conversationState[bot.displayName];
      const botMsg = bot['bot-msgs'].find(m => m.key === currentKey);
      
      if (!botMsg) {
        console.log(`${colors.red}Error: Could not find bot message with key "${currentKey}"${colors.reset}`);
        break;
      }
      
      // Bot speaks
      console.log(`${colors.bright}${bot.displayName}:${colors.reset} ${botMsg.content}`);
      this.botLikes[bot.displayName] = botMsg.like;
      this.messagesExchanged++;
      
      // Check if there are choices
      if (!botMsg.choices || botMsg.choices.length === 0) {
        console.log(`\n${colors.yellow}[Conversation ended]${colors.reset}\n`);
        await this.ask('Press Enter to continue...');
        return;
      }
      
      // Check if we've reached the message limit
      if (this.messagesExchanged >= this.maxMessagesPerBot) {
        console.log(`\n${colors.yellow}🔔 BUZZER! Time's up!${colors.reset}\n`);
        await this.ask('Press Enter to continue...');
        return;
      }
      
      // User picks a choice
      console.log('');
      botMsg.choices.forEach((choiceKey, idx) => {
        const userMsg = bot['user-msgs'].find(m => m.key === choiceKey);
        if (userMsg) {
          console.log(`${colors.green}${idx + 1}.${colors.reset} ${userMsg.content}`);
        }
      });
      
      console.log('');
      const answer = await this.ask(`${colors.cyan}Your choice (1-${botMsg.choices.length}, or quit/restart): ${colors.reset}`);
      
      if (answer.toLowerCase() === 'quit') {
        this.quit();
        return;
      }
      
      if (answer.toLowerCase() === 'restart') {
        await this.restart();
        return;
      }
      
      const choiceNum = parseInt(answer);
      if (isNaN(choiceNum) || choiceNum < 1 || choiceNum > botMsg.choices.length) {
        console.log(`${colors.red}Invalid choice. Please try again.${colors.reset}\n`);
        continue;
      }
      
      const selectedKey = botMsg.choices[choiceNum - 1];
      const userMsg = bot['user-msgs'].find(m => m.key === selectedKey);
      
      if (!userMsg) {
        console.log(`${colors.red}Error: Could not find user message with key "${selectedKey}"${colors.reset}`);
        break;
      }
      
      console.log(`\n${colors.bright}You:${colors.reset} ${userMsg.content}\n`);
      this.conversationState[bot.displayName] = userMsg.next;
      this.messagesExchanged++;
      
      // Check again if we've reached the limit after user response
      if (this.messagesExchanged >= this.maxMessagesPerBot) {
        console.log(`${colors.yellow}🔔 BUZZER! Time's up!${colors.reset}\n`);
        await this.ask('Press Enter to continue...');
        return;
      }
    }
  }

  async endOfRound() {
    this.clearScreen();
    console.log(`${colors.bright}${colors.magenta}╔════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}║              END OF ROUND ${this.currentRound}                        ║${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}╚════════════════════════════════════════════════════╝${colors.reset}\n`);
    
    // User picks who to continue with
    console.log(`${colors.yellow}Who would you like to continue dating?${colors.reset}\n`);
    
    const stillInterested = this.selectedBots.filter(bot => this.userChoices[bot.displayName]);
    
    stillInterested.forEach((bot, idx) => {
      const like = this.botLikes[bot.displayName];
      console.log(`${colors.green}${idx + 1}.${colors.reset} ${bot.displayName}`);
    });
    
    console.log(`${colors.green}${stillInterested.length + 1}.${colors.reset} Continue with all\n`);
    
    const answer = await this.ask(`${colors.cyan}Select numbers separated by spaces (e.g., "1 3 5"), "all", or "none": ${colors.reset}`);
    
    if (answer.toLowerCase() === 'quit') {
      this.quit();
      return;
    }
    
    if (answer.toLowerCase() === 'restart') {
      await this.restart();
      return;
    }
    
    // Reset choices
    this.selectedBots.forEach(bot => {
      this.userChoices[bot.displayName] = false;
    });
    
    if (answer.toLowerCase() === 'all') {
      stillInterested.forEach(bot => {
        this.userChoices[bot.displayName] = true;
      });
    } else if (answer.toLowerCase() !== 'none') {
      const selections = answer.split(/\s+/).map(n => parseInt(n));
      selections.forEach(num => {
        if (num > 0 && num <= stillInterested.length) {
          this.userChoices[stillInterested[num - 1].displayName] = true;
        }
      });
    }
    
    // Bots decide if they want to continue
    // Their threshold increments by 1 each round (starting round 2), capped at 10
    const newSelectedBots = [];
    
    this.selectedBots.forEach(bot => {
      if (this.userChoices[bot.displayName]) {
        const botLike = this.botLikes[bot.displayName];
        const baseThreshold = bot['advance-round'] || 0;
        const incrementedThreshold = Math.min(baseThreshold + (this.currentRound - 1), 10);
        
        if (botLike >= incrementedThreshold) {
          newSelectedBots.push(bot);
        } else {
          this.userChoices[bot.displayName] = false;
        }
      }
    });
    
    this.selectedBots = newSelectedBots;
    
    // Show results
    console.log('');
    if (this.selectedBots.length === 0) {
      await this.gameOver('Nobody wants to continue dating you. 💔');
      return;
    }
    
    console.log(`${colors.green}Still in the game:${colors.reset}`);
    this.selectedBots.forEach(bot => {
      console.log(`  • ${bot.displayName}`);
    });
    console.log('');
    
    // Check win condition
    if (this.currentRound >= 4 && this.selectedBots.length === 1) {
      await this.gameOver(`You found your match with ${this.selectedBots[0].displayName}! 💕`, true);
      return;
    }
    
    // Continue to next round
    this.currentRound++;
    await this.ask('Press Enter to continue to the next round...');
    await this.playRound();
  }

  async gameOver(message, win = false) {
    this.clearScreen();
    console.log(`${colors.bright}${colors.magenta}╔════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}║                  GAME OVER                         ║${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}╚════════════════════════════════════════════════════╝${colors.reset}\n`);
    
    if (win) {
      console.log(`${colors.green}${colors.bright}${message}${colors.reset}\n`);
    } else {
      console.log(`${colors.red}${message}${colors.reset}\n`);
    }
    
    const answer = await this.ask(`${colors.cyan}Play again? (yes/no): ${colors.reset}`);
    
    if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
      await this.restart();
    } else {
      this.quit();
    }
  }

  async restart() {
    this.characters = [];
    this.selectedBots = [];
    this.currentRound = 1;
    this.currentBotIndex = 0;
    this.messagesExchanged = 0;
    this.conversationState = {};
    this.userChoices = {};
    this.botLikes = {};
    
    await this.startGame();
  }

  quit() {
    console.log(`\n${colors.yellow}Thanks for playing! 💘${colors.reset}\n`);
    this.rl.close();
    process.exit(0);
  }
}

// Start the game
const game = new SpeedDatingGame();
game.startGame();