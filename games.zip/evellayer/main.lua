#!/usr/bin/env lua

-- Funky/Scary CLI State Machine Game
-- Features: State machine design, random events, funky music descriptions, survival mechanics

math.randomseed(os.time())

-- Game state structure
local game = {
    current_state = "start",
    health = 100,
    sanity = 100,
    inventory = {},
    moves = 0,
    beat_counter = 0,
    has_flashlight = false,
    has_key = false,
    escaped = false
}

-- State definitions
local states = {}

-- Utility functions
local function clear_screen()
    if package.config and package.config:sub(1,1) == '\\' then
        os.execute("cls")
    else
        os.execute("clear")
    end
end

local function press_any_key()
    io.write("\nPress Enter to continue...")
    io.read()
end

local function add_inventory(item)
    table.insert(game.inventory, item)
    if item == "flashlight" then game.has_flashlight = true end
    if item == "rusty key" then game.has_key = true end
end

local function remove_inventory(item)
    for i, v in ipairs(game.inventory) do
        if v == item then
            table.remove(game.inventory, i)
            return true
        end
    end
    return false
end

local function get_inventory_string()
    if #game.inventory == 0 then
        return "empty"
    else
        return table.concat(game.inventory, ", ")
    end
end

local function funky_beat()
    game.beat_counter = game.beat_counter + 1
    local beats = {"*thump*", "*wah-wah*", "*skronk*", "*brrrap*", "*doo-doo*", "*chk-chk*"}
    return beats[game.beat_counter % #beats + 1]
end

local function damage(amount)
    game.health = math.max(0, game.health - amount)
    if game.health <= 0 then
        game.current_state = "game_over"
    end
end

local function sanity_drain(amount)
    game.sanity = math.max(0, game.sanity - amount)
    if game.sanity <= 0 then
        game.current_state = "madness"
    end
end

-- State: Start
states.start = {
    enter = function()
        clear_screen()
        print([[

  ███████╗██╗   ██╗███████╗██╗     ██╗      █████╗ ██╗   ██╗███████╗██████╗ 
  ██╔════╝██║   ██║██╔════╝██║     ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗
  █████╗  ██║   ██║█████╗  ██║     ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝
  ██╔══╝  ╚██╗ ██╔╝██╔══╝  ██║     ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗
  ███████╗ ╚████╔╝ ███████╗███████╗███████╗██║  ██║   ██║   ███████╗██║  ██║
  ╚══════╝  ╚═══╝  ╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
                                                                            
  A FUNKY/SCARY ADVENTURE
]])
        print("\nYou wake up in a dark, abandoned mansion. The air smells of dust and decay.")
        print("Your head throbs... how did you get here? The last thing you remember is...")
        print("a funky bassline echoing through the streets. *thump* *thump* *thump*")
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        press_any_key()  -- ✅ FIXED: was 'press_any_root'
    end,
    
    update = function()
        game.current_state = "foyer"
    end
}

-- State: Foyer
states.foyer = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " You stand in the grand foyer. Moonlight filters through")
        print("broken stained glass windows, casting eerie patterns on the floor.")
        print("To the north: a grand staircase leading upstairs")
        print("To the east: a hallway with flickering lights")
        print("To the west: a heavy oak door with strange carvings")
        
        if not game.has_flashlight then
            print("\nSomething glints near the coat rack...")
        end
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhere do you go? (north/east/west/investigate)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "north" then
            game.current_state = "upstairs"
        elseif input == "east" then
            game.current_state = "hallway"
        elseif input == "west" then
            if game.has_key then
                game.current_state = "library"
            else
                print("\nThe door is locked! You need a key.")
                press_any_key()
            end
        elseif input == "investigate" then
            if not game.has_flashlight then
                print("\nYou find a dusty flashlight! It still works!")
                add_inventory("flashlight")
                press_any_key()
            else
                print("\nNothing else here...")
                press_any_key()
            end
        else
            print("\nInvalid direction! Try again.")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(2)
    end
}

-- State: Upstairs
states.upstairs = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " The stairs creak ominously as you climb.")
        print("Up here, the air feels colder. Three doors line the hallway:")
        print("Door 1: Slightly ajar, faint scratching sounds")
        print("Door 2: Covered in strange symbols that seem to shift")
        print("Door 3: Locked with a heavy padlock")
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhich door? (1/2/3/down)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "1" then
            game.current_state = "bedroom"
        elseif input == "2" then
            game.current_state = "ritual_room"
        elseif input == "3" then
            print("\nThe padlock is too strong to break.")
            press_any_key()
        elseif input == "down" then
            game.current_state = "foyer"
        else
            print("\nInvalid choice!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(3)
    end
}

-- State: Hallway
states.hallway = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " The hallway stretches into darkness. Flickering bulbs")
        print("cast long, dancing shadows. Something wet drips from the ceiling.")
        print("At the end of the hall, a door stands slightly open.")
        print("Halfway down, a vent cover hangs loose.")
        
        if not game.has_key then
            print("\nSomething metallic glints near the vent...")
        end
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhat do you do? (continue/vent/investigate/back)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "continue" then
            if math.random() > 0.7 then
                print("\nA shadow darts across the hallway! You take 10 damage!")
                damage(10)
                press_any_key()
            else
                game.current_state = "basement"
            end
        elseif input == "vent" then
            print("\nYou squeeze into the vent. It's tight and dusty.")
            if math.random() > 0.5 then
                print("You find a hidden passage!")
                game.current_state = "secret_room"
            else
                print("Dead end. You crawl back out, covered in grime. (-5 sanity)")
                sanity_drain(5)
                press_any_key()
            end
        elseif input == "investigate" then
            if not game.has_key then
                print("\nYou find a rusty key! It looks old but functional.")
                add_inventory("rusty key")
                press_any_key()
            else
                print("\nNothing else here...")
                press_any_key()
            end
        elseif input == "back" then
            game.current_state = "foyer"
        else
            print("\nInvalid action!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(2)
    end
}

-- State: Bedroom
states.bedroom = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " An old bedroom. The bed is neatly made but covered")
        print("in thick dust. A music box sits on the nightstand.")
        print("The scratching sound seems to come from inside the closet.")
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhat do you do? (music box/closet/back)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "music box" then
            print("\nYou wind the music box. It plays a hauntingly familiar tune...")
            print("Suddenly, the melody shifts into a funky bassline! *wah-wah*")
            print("Your sanity increases by 10! (The funk heals the soul)")
            game.sanity = math.min(100, game.sanity + 10)
            press_any_key()
        elseif input == "closet" then
            if math.random() > 0.6 then
                print("\nA spectral figure lunges at you! (-20 health)")
                damage(20)
                press_any_key()
            else
                print("\nThe closet is empty... just your imagination.")
                press_any_key()
            end
        elseif input == "back" then
            game.current_state = "upstairs"
        else
            print("\nInvalid action!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(3)
    end
}

-- State: Ritual Room
states.ritual_room = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " This room reeks of incense and something metallic.")
        print("Strange symbols cover the walls, pulsing with an eerie light.")
        print("In the center, a stone altar holds a glowing crystal.")
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhat do you do? (crystal/leave)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "crystal" then
            if math.random() > 0.4 then
                print("\nThe crystal pulses brighter! You feel its energy...")
                print("Your health is restored by 20 points!")
                game.health = math.min(100, game.health + 20)
                press_any_key()
            else
                print("\nThe crystal emits a piercing shriek! (-25 sanity)")
                sanity_drain(25)
                press_any_key()
            end
        elseif input == "leave" then
            game.current_state = "upstairs"
        else
            print("\nInvalid action!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(5)
    end
}

-- State: Basement
states.basement = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " The basement is damp and cold. Rusted pipes line")
        print("the walls, dripping water rhythmically. *drip... drip... drip*")
        print("In the corner, an old record player spins silently.")
        print("A heavy door with a padlock blocks the exit.")
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhat do you do? (record player/door/back)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "record player" then
            print("\nYou place the needle on the record. A deep bassline emerges!")
            print("*brrrap* *chk-chk* The funky beat fills the room!")
            print("The padlock on the door begins to rattle...")
            if game.has_key then
                print("The key in your pocket grows warm!")
            end
            press_any_key()
        elseif input == "door" then
            if game.has_key then
                print("\nYou unlock the door! Freedom awaits!")
                game.escaped = true
                game.current_state = "escape"
            else
                print("\nThe door is padlocked. You need a key.")
                press_any_key()
            end
        elseif input == "back" then
            game.current_state = "hallway"
        else
            print("\nInvalid action!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(4)
    end
}

-- State: Secret Room
states.secret_room = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " You've found a hidden room! Shelves line the walls,")
        print("filled with dusty vinyl records and strange artifacts.")
        print("A single record glows with an otherworldly light.")
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhat do you do? (glowing record/leave)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "glowing record" then
            print("\nYou take the glowing record. It hums with power!")
            add_inventory("glowing record")
            print("As you hold it, visions flood your mind...")
            print("You see the exit! (+15 sanity from revelation)")
            game.sanity = math.min(100, game.sanity + 15)
            press_any_key()
        elseif input == "leave" then
            game.current_state = "hallway"
        else
            print("\nInvalid action!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(2)
    end
}

-- State: Library
states.library = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " The library is vast, filled with ancient tomes.")
        print("Bookshelves stretch into darkness. A grandfather clock ticks loudly.")
        print("On a reading desk, an open book displays a map of the mansion.")
        
        print("\nHealth: " .. game.health .. " | Sanity: " .. game.sanity)
        print("Inventory: " .. get_inventory_string())
        print("\nWhat do you do? (map/clock/leave)")
    end,
    
    update = function(input)
        input = input:lower()
        
        if input == "map" then
            print("\nThe map shows secret passages and the location of the exit!")
            print("You memorize the layout. (+10 sanity from knowledge)")
            game.sanity = math.min(100, game.sanity + 10)
            press_any_key()
        elseif input == "clock" then
            print("\nYou open the clock face. Inside, a small compartment holds...")
            if not game.has_flashlight then
                print("a flashlight! Now you can see in the dark.")
                add_inventory("flashlight")
            else
                print("nothing. You've already taken the flashlight.")
            end
            press_any_key()
        elseif input == "leave" then
            game.current_state = "foyer"
        else
            print("\nInvalid action!")
            press_any_key()
        end
        
        game.moves = game.moves + 1
        sanity_drain(2)
    end
}

-- State: Escape
states.escape = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " You burst through the door into the cool night air!")
        print("Freedom! You made it out alive!")
        print("\nFinal Stats:")
        print("Health: " .. game.health)
        print("Sanity: " .. game.sanity)
        print("Moves: " .. game.moves)
        print("Inventory: " .. get_inventory_string())
        
        if game.sanity > 80 then
            print("\nYou escaped with your mind intact! The funky beats saved you!")
        elseif game.health > 80 then
            print("\nYou're battered but alive! Time to find that bass player!")
        else
            print("\nYou barely made it... but you're free! The mansion fades behind you.")
        end
        
        print("\nThanks for playing!")
        os.exit()
    end
}

-- State: Game Over
states.game_over = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " Your body collapses as the darkness consumes you.")
        print("The last thing you hear is a distorted bassline fading into silence...")
        print("\nGAME OVER")
        print("\nFinal Stats:")
        print("Sanity: " .. game.sanity)
        print("Moves: " .. game.moves)
        os.exit()
    end
}

-- State: Madness
states.madness = {
    enter = function()
        clear_screen()
        print("\n" .. funky_beat() .. " Your mind shatters like broken vinyl.")
        print("The walls melt into a psychedelic nightmare of sound and color.")
        print("You become one with the funky void...")
        print("\nDESCENDED INTO MADNESS")
        print("\nFinal Stats:")
        print("Health: " .. game.health)
        print("Moves: " .. game.moves)
        os.exit()
    end
}

-- Main game loop
function main()
    -- Initial state
    states[game.current_state].enter()
    
    while true do
        if states[game.current_state].update then
            io.write("\n> ")
            local input = io.read("*l")  -- Read a full line
            if input then
                input = input:lower():gsub("^%s+", ""):gsub("%s+$", "")  -- Trim
                states[game.current_state].update(input)
            else
                -- Handle EOF (e.g., Ctrl+D)
                print("\nGoodbye!")
                break
            end
        else
            -- State handles its own transition
            states[game.current_state].update()
        end
        
        -- Enter new state if changed
        if states[game.current_state] and states[game.current_state].enter then
            states[game.current_state].enter()
        end
    end
end

-- Start the game
main()