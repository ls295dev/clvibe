#!/usr/bin/env php
<?php

class LexicalSingularity {
    private $stability = 100;
    private $inventory = ["Seed"];
    private $currentTheme = "VOID";
    private $turn = 1;
    private $isBossActive = false;
    
    private $lexicon = [
        "PHYSICAL" => ["stone", "heavy", "iron", "mountain", "anchor", "crush"],
        "ETHEREAL" => ["ghost", "whisper", "nebula", "dream", "spirit", "vortex"],
        "VIOLENT"  => ["shatter", "razor", "plasma", "scorch", "impact", "fury"],
        "VOID"     => ["null", "cipher", "silent", "entropy", "abyss", "static"]
    ];

    public function run() {
        $this->clear();
        $this->drawIntro();

        while ($this->stability > 0) {
            if ($this->turn % 10 === 0 && !$this->isBossActive) {
                $this->triggerBoss();
            }

            if ($this->isBossActive) {
                $this->handleBossTurn();
            } else {
                $this->handleStandardTurn();
            }

            if ($this->stability <= 0) break;
            $this->turn++;
        }

        $this->drawGameOver();
    }

    private function handleStandardTurn() {
        $this->renderUI();
        $input = strtolower(trim(readline(">> Inject concept: ")));

        if ($input === 'quit') exit("\nExiting reality...\n");
        if (empty($input)) return;

        $vibe = $this->analyzeVibe($input);
        $impact = $this->calculateImpact($input);
        
        $this->stability -= $impact;
        $this->currentTheme = $vibe;

        echo "\n\033[1;34m[SHIFT]\033[0m The world reconfigures into a \033[1;33m$vibe\033[0m state.\n";
        $this->generateDescription($input, $vibe);
        
        if (rand(1, 4) === 1) $this->gainShard($vibe);
    }

    private function triggerBoss() {
        $this->isBossActive = true;
        $this->clear();
        echo "\033[1;31m";
        echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
        echo "!! WARNING: SEMANTIC ANOMALY DETECTED           !!\n";
        echo "!! THE GREAT LEXIVORE HAS ARRIVED               !!\n";
        echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\033[0m";
        echo "\nIt feeds on the consonants of your thoughts.\n\n";
        sleep(1);
    }

    private function handleBossTurn() {
        // Correctly pick a random word from a random theme
        $randomThemeKey = array_rand($this->lexicon);
        $bossWord = $this->lexicon[$randomThemeKey][array_rand($this->lexicon[$randomThemeKey])];
        
        $scrambled = str_shuffle($bossWord);
        
        echo "\n\033[1;31m[BOSS] THE LEXIVORE SCREAMS: \033[5m$scrambled\033[0m\n";
        echo "STABILITY: {$this->stability}%\n";
        $input = strtolower(trim(readline(">> UNSCRAMBLE OR DIE: ")));

        if ($input === $bossWord) {
            echo "\n\033[1;32mCRITICAL HIT!\033[0m You stabilized the word. The Lexivore retreats.\n";
            $this->stability = min(100, $this->stability + 20);
            $this->isBossActive = false;
        } else {
            $damage = rand(15, 30);
            $this->stability -= $damage;
            echo "\n\033[1;31mWRONG.\033[0m The correct word was '$bossWord'. (-$damage Stability)\n";
            // Boss stays active until you get one right or die
        }
    }

    private function analyzeVibe($input) {
        $bestTheme = "VOID";
        $maxScore = -1;

        foreach ($this->lexicon as $theme => $anchors) {
            foreach ($anchors as $anchor) {
                if (metaphone($input) === metaphone($anchor)) return $theme;
                
                similar_text($input, $anchor, $percent);
                if ($percent > $maxScore) {
                    $maxScore = $percent;
                    $bestTheme = $theme;
                }
            }
        }
        return $bestTheme;
    }

    private function calculateImpact($input) {
        $target = $this->lexicon[$this->currentTheme][0];
        $dist = levenshtein($input, $target);
        return max(5, min(25, $dist - (strlen($input) / 2)));
    }

    private function gainShard($theme) {
        $shard = $this->lexicon[$theme][array_rand($this->lexicon[$theme])];
        $this->inventory[] = ucfirst($shard);
        echo "\033[1;36m[LOOT]\033[0m You crystallized a fragment of '$shard'.\n";
    }

    private function generateDescription($word, $theme) {
        $adjs = ["viscous", "crystalline", "roaring", "obsidian", "hollow"];
        $adj = $adjs[array_rand($adjs)];
        echo "The concept of '$word' manifests as a $adj horizon.\n";
    }

    private function renderUI() {
        echo "\n" . str_repeat("=", 50) . "\n";
        $color = $this->stability > 40 ? "32" : "31";
        echo "TURN: {$this->turn} | THEME: \033[1;35m{$this->currentTheme}\033[0m\n";
        
        $barCount = max(0, (int)($this->stability / 5));
        echo "STABILITY: \033[1;{$color}m{$this->stability}%\033[0m " . str_repeat("■", $barCount) . "\n";
        
        echo "SHARDS: " . implode(" · ", array_slice($this->inventory, -6)) . "\n";
        echo str_repeat("=", 50) . "\n";
    }

    private function drawIntro() {
        echo "\033[1;36m";
        echo "    __    _______  __  ____  ____  ____ \n";
        echo "   /  |  / ___/\\ \\/ / / __ \\/ __ \\/ __ \\\n";
        echo "  / /| |/ __/   \\  / / /_/ / /_/ / /_/ /\n";
        echo " /_/ |_/____/   /_/  \\____/\\____/\\____/ \n";
        echo "      --- THE LEXICAL SINGULARITY ---   \n\033[0m";
        echo " Survive the semantic drift. Don't let the Lexivore eat your words.\n\n";
    }

    private function drawGameOver() {
        echo "\n\n\033[1;31m[THE VOID CLOSES]\033[0m\n";
        echo "Final Score: " . ($this->turn * 10) . "\n";
        echo "Your mind was composed of: " . implode(", ", $this->inventory) . "\n\n";
    }

    private function clear() {
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            passthru('cls');
        } else {
            passthru('clear');
        }
    }
} // <--- This was the missing brace!

$game = new LexicalSingularity();
$game->run();
