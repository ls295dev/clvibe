#!/usr/bin/env php
<?php

class KEndRadio {
    private $signal = 100;
    private $static = 0;
    private $hoursToSunset = 15;
    private $survivorCount = 42;
    private $isBossActive = false;
    private $bossHealth = 100;
    private $logFile = 'transmission_log.txt';

    private $eggs = [
        'coffee' => ["The aroma of phantom caffeine fills the bunker. Energy spikes.", 12, -8, "THE KING CANNOT MOVE IF YOU ARE VIGILANT."],
        'vinyl'  => ["The scratch of a needle. A jazz melody cuts the static.", 25, -20, "MELODY IS A CAGE FOR THE SILENT."],
        'stars'  => ["You describe the dead constellations. The sky stops sagging.", 8, -12, "HE LIVES IN THE VOIDS BETWEEN LIGHT."],
        'memory' => ["A story from Before. The Static screams in agony.", 18, -10, "THE KING HAS NO HISTORY. FEED HIM YOURS."],
        'bunker' => ["You talk about your walls. Scratching begins from WITHOUT.", -15, 25, "HE IS ALREADY AT THE DOOR."],
    ];

    public function __construct() {
        // Prepare the log file
        file_put_contents($this->logFile, "--- K-END TRANSMISSION LOG BEGINS ---\n\n");
    }

    public function run() {
        $this->clear();
        $this->drawLogo();

        while ($this->signal > 0 && $this->hoursToSunset > 0) {
            $this->renderUI();
            
            $input = readline("\033[1;33m[MIC OPEN]\033[0m >> ");
            if ($input === 'quit' || empty($input)) break;

            $this->saveToLog($input);
            $this->processBroadcast($input);
            
            if ($this->static > 75 && !$this->isBossActive) {
                $this->triggerBoss();
            }

            if ($this->isBossActive) {
                $this->bossTurn();
            }

            $this->hoursToSunset--;
        }

        $this->endGame();
    }

    private function processBroadcast($text) {
        $this->clear();
        $foundEgg = false;

        foreach ($this->eggs as $key => $data) {
            if (stripos($text, $key) !== false) {
                echo "\n\033[1;36m📡 [RESONANCE]\033[0m {$data[0]}\n";
                echo "\033[1;34m📜 [HINT]\033[0m \033[3m{$data[3]}\033[0m\n\n";
                $this->signal = min(100, $this->signal + $data[1]);
                $this->static = max(0, $this->static + $data[2]);
                $foundEgg = true;
                sleep(2);
            }
        }

        $vibe = (strlen($text) > 30) ? 'hope' : 'fear';
        $this->static += ($vibe === 'fear' ? 10 : -6);
        $this->signal -= rand(4, 8);

        $response = $this->getWastelandResponse($vibe);
        echo "\n\033[1;32mWASTELAND FEEDBACK:\033[0m " . $this->glitchText($response) . "\n";
        sleep(1);
    }

    private function triggerBoss() {
        $this->isBossActive = true;
        $this->clear();
        echo "\033[1;31m" . str_repeat("!", 60) . "\n";
        echo "!! WARNING: THE MUTED KING HAS HIJACKED THE FREQUENCY      !!\n";
        echo str_repeat("!", 60) . "\033[0m\n\n";
        sleep(2);
    }

    private function bossTurn() {
        echo "\033[1;31m[VOICELESS DRAIN]\033[0m THE KING IS COMPRESSING THE SIGNAL...\n";
        echo "KING MASK: " . str_repeat("?", (int)($this->bossHealth / 5)) . " ({$this->bossHealth})\n";
        
        $atk = readline("\033[1;37mOVERPOWER THE SILENCE:\033[0m ");
        $this->saveToLog("[BOSS FIGHT] $atk");

        $mult = (stripos($atk, 'vinyl') !== false || stripos($atk, 'memory') !== false) ? 4 : 1;
        $damage = (strlen($atk) * $mult);
        
        $this->bossHealth -= $damage;
        $this->signal -= rand(12, 22);

        if ($this->bossHealth <= 0) {
            echo "\n\033[1;33mTHE KING DISSOLVES INTO WHITE NOISE. THE AIR BREATHES AGAIN.\033[0m\n";
            $this->isBossActive = false;
            $this->static = 0;
            sleep(2);
        }
    }

    private function glitchText($text) {
        $intensity = $this->isBossActive ? 65 : $this->static;
        if ($intensity < 10) return $text;

        $chars = str_split($text);
        foreach ($chars as &$c) {
            if (rand(0, 100) < $intensity) {
                $glitches = ['█', '▓', '▒', '░', '?', '!', 'Ø', '∑', '†'];
                $c = $glitches[array_rand($glitches)];
            }
        }
        return implode('', $chars);
    }

    private function getWastelandResponse($vibe) {
        $responses = [
            'fear' => ["A radio in the debris sparks and dies.", "The shadows outside your hatch are getting thicker.", "The survivors are weeping in the dark."],
            'hope' => ["A distant fire is lit in a skyscraper.", "A scavenger laughs for the first time in years.", "The signal pulls a family together."],
        ];
        return $responses[$vibe][array_rand($responses[$vibe])];
    }

    private function renderUI() {
        echo "\n" . str_repeat("—", 60) . "\n";
        echo "K-END RADIO | SUNSET: {$this->hoursToSunset}h | SURVIVORS: {$this->survivorCount}\n";
        
        $sigBar = str_repeat("⚡", max(0, (int)($this->signal / 10)));
        $staBar = str_repeat("░", max(0, (int)($this->static / 10)));
        
        echo "SIGNAL: [\033[1;32m$sigBar\033[0m] {$this->signal}%  |  STATIC: [\033[1;31m$staBar\033[0m] {$this->static}%\n";
        echo str_repeat("—", 60) . "\n\n";
    }

    private function saveToLog($text) {
        file_put_contents($this->logFile, "[Hour " . (15 - $this->hoursToSunset) . "] " . $text . "\n", FILE_APPEND);
    }

private function drawLogo() {
        echo "\033[1;31m";
        echo "  _  __     ______ _   _ _____  \n";
        echo " | |/ /    |  ____| \ | |  __ \ \n";
        echo " | ' /_____| |__  |  \| | |  | |\n";
        echo " |  <______|  __| | . ` | |  | |\n";
        echo " | . \     | |____| |\  | |__| |\n";
        echo " |_|\_\    |______|_| \_|_____/ \n";
        echo "     THE LAST DJ ON EARTH\n\033[0m";
        echo "\nYour voice is the only thing keeping the dark away.\n";
        echo "If the Static wins, the broadcast ends forever.\n\n";
        sleep(2);
    }

    private function endGame() {
        $this->clear();
        if ($this->hoursToSunset <= 0) {
            echo "\033[1;32m[THE SUN HAS SET]\033[0m\n";
            echo "The world is quiet, but it isn't empty. Your voice won.\n";
        } else {
            echo "\033[1;31m[RADIO SILENCE]\033[0m\n";
            echo "The static took you. You are part of the noise now.\n";
        }
        echo "Your last transmissions were saved to: {$this->logFile}\n\n";
    }

    private function clear() { passthru(strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'cls' : 'clear'); }
}

$game = new KEndRadio();
$game->run();