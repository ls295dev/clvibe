#!/usr/bin/env lua

-- SPAKE2 Love Confession Game
-- A game about cryptography, love, and group chats

-- Game state
local game = {
    password = "stargazing2019",
    friend_name = "Alex",
    confession = "Remember our promise? I need to tell you something important. Can we talk somewhere private?",
    encrypted_confession = "",
    friend_response_encrypted = "",
    friend_response_plain = "I remember. Meet me at the old place. We both know where. I'll be waiting.",
    chat_history = {},
    game_over = false,
    confession_sent = false,
    confession_encrypted = false,
    turn_count = 0,
    player_name = "You"
}

-- Expanded participants (50 people)
local participants = {
    {name = "Alex", personality = "friend"},
    -- Trolls (15)
    {name = "Jordan", personality = "troll"},
    {name = "Riley", personality = "troll"},
    {name = "River", personality = "troll"},
    {name = "Drew", personality = "troll"},
    {name = "Kai", personality = "troll"},
    {name = "Parker", personality = "troll"},
    {name = "Winter", personality = "troll"},
    {name = "Phoenix", personality = "troll"},
    {name = "Raven", personality = "troll"},
    {name = "Storm", personality = "troll"},
    {name = "Blaze", personality = "troll"},
    {name = "Shadow", personality = "troll"},
    {name = "Wraith", personality = "troll"},
    {name = "Vex", personality = "troll"},
    {name = "Cipher", personality = "troll"},
    -- Gossips (15)
    {name = "Morgan", personality = "gossip"},
    {name = "Quinn", personality = "gossip"},
    {name = "Blake", personality = "gossip"},
    {name = "Hayden", personality = "gossip"},
    {name = "Micah", personality = "gossip"},
    {name = "Skylar", personality = "gossip"},
    {name = "Brooklyn", personality = "gossip"},
    {name = "Peyton", personality = "gossip"},
    {name = "Kendall", personality = "gossip"},
    {name = "Reagan", personality = "gossip"},
    {name = "Rowan", personality = "gossip"},
    {name = "Sage", personality = "gossip"},
    {name = "Avery", personality = "gossip"},
    {name = "Emerson", personality = "gossip"},
    {name = "Finley", personality = "gossip"},
    -- Neutrals (19)
    {name = "Sam", personality = "neutral"},
    {name = "Casey", personality = "neutral"},
    {name = "Dakota", personality = "neutral"},
    {name = "Cameron", personality = "neutral"},
    {name = "Jamie", personality = "neutral"},
    {name = "Logan", personality = "neutral"},
    {name = "Noel", personality = "neutral"},
    {name = "Reese", personality = "neutral"},
    {name = "Taylor", personality = "neutral"},
    {name = "Aria", personality = "neutral"},
    {name = "Charlie", personality = "neutral"},
    {name = "Ellis", personality = "neutral"},
    {name = "Harper", personality = "neutral"},
    {name = "Indigo", personality = "neutral"},
    {name = "Jules", personality = "neutral"},
    {name = "Kit", personality = "neutral"},
    {name = "Lane", personality = "neutral"},
    {name = "Marlowe", personality = "neutral"},
    {name = "Nova", personality = "neutral"}
}

-- Expanded message templates
local messages = {
    neutral = {
        "anyone online?",
        "what's everyone doing tonight?",
        "this weather is insane",
        "lol yeah",
        "did anyone watch that thing yesterday?",
        "I'm exhausted",
        "what's the plan for later?",
        "same honestly",
        "fair enough",
        "brb getting food",
        "back",
        "oh interesting",
        "makes sense",
        "true true",
        "idk maybe",
        "probably not gonna make it tonight",
        "has anyone seen the news?",
        "typical",
        "yeah that tracks",
        "good point",
        "anyway",
        "what were we talking about?",
        "lost track of the convo",
        "mood",
        "honestly same energy",
        "not gonna lie that's fair",
        "speaking of which",
        "random question but",
        "nvm figured it out",
        "thanks everyone"
    },
    gossip = {
        "wait WHAT",
        "omg I need context",
        "someone explain what's happening",
        "I'm so lost but I'm HERE for it",
        "screenshot that before it gets deleted",
        "this is wild",
        "no way that actually happened",
        "I heard something about this",
        "okay but what's the full story?",
        "this keeps getting better",
        "I have QUESTIONS",
        "everyone stay calm but this is huge",
        "did I miss something important?",
        "going back to read everything",
        "oh THIS is interesting",
        "I'm invested now",
        "tell me everything",
        "wait go back what did they say?",
        "I'm refreshing constantly",
        "this chat is never boring",
        "main character moment honestly",
        "the DRAMA",
        "I can't look away",
        "someone fill me in",
        "okay I see you 👀",
        "things are HAPPENING",
        "I need the full timeline",
        "this is why I stay in this chat",
        "entertainment = delivered",
        "popcorn ready 🍿"
    },
    troll = {
        "cringe",
        "yikes on bikes",
        "this is why we can't have nice things",
        "embarrassing",
        "please delete",
        "second-hand embarrassment rn",
        "🤡",
        "WeirdChamp",
        "that's gonna be a no from me",
        "big L",
        "couldn't be me",
        "imagine posting that",
        "this ain't it chief",
        "reading comprehension: 0",
        "tell me you're joking",
        "💀💀💀",
        "who's gonna tell them",
        "you really thought this was it huh",
        "the audacity",
        "absolutely not",
        "this is painful to watch",
        "I'm logging off",
        "my eyes",
        "can we not",
        "why would you type that",
        "zero self-awareness",
        "unhinged behavior",
        "touch grass",
        "chronically online moment",
        "bro what",
        "I have no words",
        "respectfully, no",
        "the way I just cringed",
        "someone take their keyboard away",
        "this is your legacy now"
    },
    friend_neutral = {
        "hey everyone",
        "how's the chat today",
        "anything interesting happening?",
        "I should probably check this more often",
        "what did I miss",
        "catching up on messages",
        "lot of activity today huh",
        "hope everyone's doing okay",
        "quiet today"
    }
}

-- Responses to unencrypted confession
local ridicule = {
    "HOLD ON DID SOMEONE JUST CONFESS IN THE GROUP CHAT",
    "NO WAY I'M SCREEN RECORDING THIS",
    "this is the content I signed up for",
    "absolutely legendary move",
    "the boldness is almost admirable",
    "this will never be forgotten",
    "group chat history being made",
    "I'm saving this forever",
    "immortalized in screenshots",
    "this is going in the hall of fame",
    "the chaos energy",
    "certified group chat moment",
    "this is peak entertainment",
    "I cannot believe what I'm witnessing",
    "they really did that in front of everyone",
    "the second-hand embarrassment is REAL",
    "I'm actually speechless",
    "this beats any reality TV",
    "I wish I could unsee this but also no",
    "the commitment to the bit",
    "posting this in my story",
    "everyone will remember this day",
    "the lack of self-preservation",
    "respect the transparency I guess?",
    "couldn't even use DMs",
    "the vulnerability is honestly concerning",
    "my jaw is on the floor",
    "they chose violence (emotional)",
    "group therapy moment unlocked"
}

-- Responses to encrypted confession
local encrypted_reactions = {
    "what language is that supposed to be",
    "keyboard broken?",
    "???",
    "did you have a stroke",
    "gibberish",
    "okay random",
    "makes zero sense but go off",
    "is this a bot",
    "weird message but whatever",
    "cryptic",
    "ok weirdo",
    "that's certainly... something",
    "I don't speak whatever that is",
    "accidentally sent a password?",
    "spam vibes",
    "glitch in the matrix",
    "broken text?",
    "unintelligible but noted",
    "...sure"
}

-- XOR function that works without bit32 library
local function xor_bytes(a, b)
    local result = 0
    local bit_val = 1
    for i = 0, 7 do
        local a_bit = math.floor(a / bit_val) % 2
        local b_bit = math.floor(b / bit_val) % 2
        if a_bit ~= b_bit then
            result = result + bit_val
        end
        bit_val = bit_val * 2
    end
    return result
end

-- Better XOR-based encryption that actually works
local function encrypt_message(text, password)
    -- Create a longer repeating key from password
    local key = ""
    local key_length = 200
    while #key < key_length do
        key = key .. password
    end
    
    local encrypted = {}
    for i = 1, #text do
        local char_byte = string.byte(text, i)
        local key_byte = string.byte(key, ((i - 1) % #key) + 1)
        local encrypted_byte = xor_bytes(char_byte, key_byte)
        table.insert(encrypted, string.format("%02X", encrypted_byte))
    end
    
    return table.concat(encrypted, "")
end

local function decrypt_message(encrypted_hex, password)
    -- Create the same repeating key
    local key = ""
    local key_length = 200
    while #key < key_length do
        key = key .. password
    end
    
    local decrypted = {}
    local pos = 1
    for i = 1, #encrypted_hex, 2 do
        local hex_pair = encrypted_hex:sub(i, i + 1)
        local encrypted_byte = tonumber(hex_pair, 16)
        if encrypted_byte then
            local key_byte = string.byte(key, ((pos - 1) % #key) + 1)
            local decrypted_byte = xor_bytes(encrypted_byte, key_byte)
            table.insert(decrypted, string.char(decrypted_byte))
            pos = pos + 1
        end
    end
    
    return table.concat(decrypted)
end

-- Initialize encrypted messages
game.encrypted_confession = encrypt_message(game.confession, game.password)
game.friend_response_encrypted = encrypt_message(game.friend_response_plain, game.password)

-- Add message to chat history
local function add_message(name, message)
    table.insert(game.chat_history, {name = name, message = message})
end

-- Simulate chat activity
local function simulate_chat()
    if game.game_over then return end
    
    local active_participants = {}
    for _, p in ipairs(participants) do
        if p.name ~= game.friend_name or not game.confession_sent then
            table.insert(active_participants, p)
        end
    end
    
    local chance = math.random(1, 100)
    if chance <= 45 then
        local participant = active_participants[math.random(#active_participants)]
        local msg_pool = messages[participant.personality] or messages.neutral
        
        if participant.name == game.friend_name then
            msg_pool = messages.friend_neutral
        end
        
        local message = msg_pool[math.random(#msg_pool)]
        add_message(participant.name, message)
    end
end

-- Show intro
local function show_intro()
    print("\n" .. string.rep("=", 70))
    print("                    ✨ CRYPTIC CONFESSIONS ✨")
    print(string.rep("=", 70))
    print("\nThe year is 2089. After the Great Internet Merge, the Global")
    print("Communications Authority mandated all personal conversations occur")
    print("in supervised public channels. Privacy is illegal. Encryption is")
    print("your only rebellion.")
    print("\nYou and " .. game.friend_name .. " have known each other since before the Merge.")
    print("Years ago, you both agreed on a secret password, just in case:")
    print("\n  🔑 Password: \"" .. game.password .. "\"")
    print("\nThere's something you've needed to say for a long time. But this")
    print("group chat has 50 members. Some are friends. Most are strangers.")
    print("Many are hostile. If you speak plainly, everyone will see. Everyone")
    print("will remember. Screenshots last forever.")
    print("\nYour carefully worded message:")
    print("  💌 \"" .. game.confession .. "\"")
    print("\n" .. string.rep("=", 70))
    print("\nType 'help' for available commands.")
    print(string.rep("=", 70) .. "\n")
end

-- Show help
local function show_help()
    print("\n" .. string.rep("-", 70))
    print("AVAILABLE COMMANDS:")
    print(string.rep("-", 70))
    print("  help           - Show this help message")
    print("  chat           - View the group chat")
    print("  encrypt <msg>  - Encrypt a message with your password")
    print("  decrypt <msg>  - Decrypt a message with your password")
    print("  send <msg>     - Send a message to the group chat")
    print("  wait           - Wait and watch the chat (simulate activity)")
    print("  info           - Show your message and password again")
    print("  quit           - Exit the game")
    print(string.rep("-", 70))
    print("\nTIP: Encrypt your message before sending it!")
    print(string.rep("-", 70) .. "\n")
end

-- Show chat
local function show_chat()
    print("\n" .. string.rep("=", 70))
    print("                    GROUP CHAT: MandatoryPublic-7749")
    print(string.rep("=", 70))
    
    if #game.chat_history == 0 then
        print("[No messages yet]")
    else
        local start = math.max(1, #game.chat_history - 20)
        for i = start, #game.chat_history do
            local msg = game.chat_history[i]
            print(string.format("%-15s: %s", msg.name, msg.message))
        end
    end
    
    print(string.rep("=", 70) .. "\n")
end

-- Show info
local function show_info()
    print("\n" .. string.rep("-", 70))
    print("YOUR INFORMATION:")
    print(string.rep("-", 70))
    print("Password: " .. game.password)
    print("Friend: " .. game.friend_name)
    print("Message: " .. game.confession)
    print(string.rep("-", 70) .. "\n")
end

-- Handle send command
local function handle_send(message)
    if game.game_over then
        print("The game is over. Type 'quit' to exit.\n")
        return
    end
    
    add_message(game.player_name, message)
    game.turn_count = game.turn_count + 1
    
    -- Check if this is the confession
    local is_confession = false
    
    -- Check if it's the encrypted confession
    if message == game.encrypted_confession then
        is_confession = true
        game.confession_encrypted = true
        game.confession_sent = true
        print("\n✉️  Message sent to the group chat.\n")
        
        -- Simulate some confusion
        for i = 1, math.random(3, 6) do
            simulate_chat()
        end
        
        -- Add encrypted reactions
        for i = 1, math.random(3, 5) do
            local reactor = participants[math.random(2, #participants)]
            local reaction = encrypted_reactions[math.random(#encrypted_reactions)]
            add_message(reactor.name, reaction)
        end
        
        -- More natural chat flow
        for i = 1, math.random(2, 4) do
            simulate_chat()
        end
        
        -- Alex responds with encrypted message
        add_message(game.friend_name, game.friend_response_encrypted)
        
        print("\n💌 " .. game.friend_name .. " has sent an encrypted message.")
        print("Use 'decrypt " .. game.friend_response_encrypted .. "' to read it.\n")
        
    -- Check if it's the plain confession or contains key phrases
    elseif message:lower():find("promise") and message:lower():find("important") 
           or message:lower():find("private") and message:lower():find("talk")
           or message == game.confession then
        is_confession = true
        game.confession_encrypted = false
        game.confession_sent = true
        game.game_over = true
        
        print("\n❌ You sent it unencrypted. The chat sees everything.\n")
        
        -- Immediate chaos
        for i = 1, math.random(8, 12) do
            simulate_chat()
            if math.random(1, 100) <= 60 then
                local ridic = ridicule[math.random(#ridicule)]
                local troll = participants[math.random(2, #participants)]
                add_message(troll.name, ridic)
            end
        end
        
        -- Alex's response
        add_message(game.friend_name, "I can't believe you just did that.")
        simulate_chat()
        simulate_chat()
        add_message(game.friend_name, "In front of everyone. Really?")
        simulate_chat()
        add_message(game.friend_name, "I need time to think. Don't contact me.")
        
        -- More mockery
        for i = 1, math.random(4, 6) do
            simulate_chat()
            local ridic = ridicule[math.random(#ridicule)]
            local troll = participants[math.random(2, #participants)]
            add_message(troll.name, ridic)
        end
        
        print("\n" .. string.rep("=", 70))
        print("                            💔 BAD END 💔")
        print(string.rep("=", 70))
        print("\nYour message spreads across the network within minutes.")
        print("Screenshots. Memes. Commentary threads. Your moment of")
        print("vulnerability becomes public property.")
        print("\n" .. game.friend_name .. " hasn't responded to any private messages.")
        print("The chat has moved on, but the damage remains.")
        print("\nIn 2089, privacy isn't just protection—it's respect.")
        print(string.rep("=", 70) .. "\n")
        
    else
        print("\n✉️  Message sent to the group chat.\n")
    end
    
    -- Regular chat simulation
    if not game.game_over and not is_confession then
        for i = 1, math.random(1, 4) do
            simulate_chat()
        end
    end
end

-- Handle encrypt command
local function handle_encrypt(message)
    local encrypted = encrypt_message(message, game.password)
    print("\n🔒 Encrypted message:")
    print("    " .. encrypted)
    print("\nCopy this to send it encrypted!\n")
end

-- Handle decrypt command
local function handle_decrypt(message)
    local decrypted = decrypt_message(message, game.password)
    print("\n🔓 Decrypted message:")
    print("    " .. decrypted)
    
    -- Check if they decrypted Alex's response
    if message == game.friend_response_encrypted and game.confession_encrypted then
        game.game_over = true
        print("\n" .. string.rep("=", 70))
        print("                           ✨ GOOD END ✨")
        print(string.rep("=", 70))
        print("\nThe message decrypts character by character. Your heart")
        print("races as the meaning becomes clear.")
        print("\nIn a world where privacy is forbidden, you carved out a")
        print("moment that belonged only to you and " .. game.friend_name .. ". The group")
        print("chat continues its endless scroll of noise and judgment,")
        print("but you're no longer paying attention.")
        print("\nYou know the old place. You both do. Some memories survive")
        print("even the Merge.")
        print("\nYou close the chat. " .. game.friend_name .. " will be waiting.")
        print(string.rep("=", 70))
        print("\n✨ You've mastered the art of cryptic confessions. ✨")
        print("\nThis is what SPAKE2 does: it turns a shared secret into")
        print("an unbreakable connection, even in the most hostile environment.\n")
    else
        print()
    end
end

-- Handle wait command
local function handle_wait()
    print("\n⏳ Watching the chat...\n")
    for i = 1, math.random(4, 8) do
        simulate_chat()
    end
    print("💬 Chat activity continued.\n")
end

-- Main game loop
local function game_loop()
    show_intro()
    
    -- Add some initial chat activity
    for i = 1, 8 do
        simulate_chat()
    end
    
    while true do
        io.write("> ")
        local input = io.read()
        
        if not input then break end
        
        input = input:match("^%s*(.-)%s*$")  -- trim
        
        if input == "" then
            -- Just simulate chat on empty input
            
        elseif input == "help" then
            show_help()
            
        elseif input == "chat" then
            show_chat()
            
        elseif input == "info" then
            show_info()
            
        elseif input == "wait" then
            handle_wait()
            
        elseif input == "quit" or input == "exit" then
            print("\n👋 Remember: in hostile environments, encryption isn't")
            print("   paranoia—it's survival. Thanks for playing.\n")
            break
            
        elseif input:sub(1, 7) == "encrypt" then
            local message = input:sub(9)
            if message ~= "" then
                handle_encrypt(message)
            else
                print("\nUsage: encrypt <message>\n")
            end
            
        elseif input:sub(1, 7) == "decrypt" then
            local message = input:sub(9)
            if message ~= "" then
                handle_decrypt(message)
            else
                print("\nUsage: decrypt <message>\n")
            end
            
        elseif input:sub(1, 4) == "send" then
            local message = input:sub(6)
            if message ~= "" then
                handle_send(message)
            else
                print("\nUsage: send <message>\n")
            end
            
        else
            print("\nUnknown command. Type 'help' for available commands.\n")
        end
        
        if game.game_over then
            print("\nThe story has concluded. Type 'quit' to exit, or 'chat' to review.\n")
        end
    end
end

-- Initialize random seed
math.randomseed(os.time())

-- Start the game
game_loop()
